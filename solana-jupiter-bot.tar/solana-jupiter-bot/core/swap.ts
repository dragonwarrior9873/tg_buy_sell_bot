import * as fs from "fs";
import { createJupiterApiClient } from "../src/index";
import {
  Connection,
  Keypair,
  VersionedTransaction,
  PublicKey,
} from "@solana/web3.js";
import splToken from "@solana/spl-token";
import { Wallet } from "@project-serum/anchor";
import bs58 from "bs58";
import { transactionSenderAndConfirmationWaiter } from "./utils/transactionSender";
import { getSignature } from "./utils/getSignature";
import { getKeypairFromEnvironment } from "@solana-developers/node-helpers";

import { Telegraf } from "telegraf";
const bot = new Telegraf("7003665688:AAE0YzeB42F6S_TpIFMdAzRK99d8jg0n7wE");

import {
  connection,
  WalletType,
  minAmount,
  maxAmount,
  tokenDecimal,
  walletCount,
  adminPrivateKey,
  adminWallet,
} from "./config";

export async function buy(ctx: any, tokenAddress: any, amount: any) {
  const jupiterQuoteApi = createJupiterApiClient();
  const wallet = new Wallet(adminWallet);
  console.log("Wallet:", wallet.publicKey.toBase58());

  // Make sure that you are using your own RPC endpoint.
  const connection = new Connection("https://api.mainnet-beta.solana.com");

  const amountBig = Math.floor(amount * 10 ** 8);
  console.log(tokenAddress, amountBig);
  // get quote
  const quote = await jupiterQuoteApi.quoteGet({
    inputMint: "So11111111111111111111111111111111111111112",
    outputMint: tokenAddress,
    amount: amountBig,
    slippageBps: 50,
    onlyDirectRoutes: false,
    asLegacyTransaction: false,
  });

  if (!quote) {
    ctx.reply("Error occured: unable to quote");
    return;
  }

  // Get serialized transaction
  const swapResult = await jupiterQuoteApi.swapPost({
    swapRequest: {
      quoteResponse: quote,
      userPublicKey: wallet.publicKey.toBase58(),
      dynamicComputeUnitLimit: true,
      prioritizationFeeLamports: "auto",
      // prioritizationFeeLamports: {
      //   autoMultiplier: 2,
      // },
    },
  });

  console.dir(swapResult, { depth: null });

  // Serialize the transaction
  const swapTransactionBuf = Buffer.from(swapResult.swapTransaction, "base64");
  var transaction = VersionedTransaction.deserialize(swapTransactionBuf);

  // Sign the transaction
  transaction.sign([wallet.payer]);
  const signature = getSignature(transaction);

  // We first simulate whether the transaction would be successful
  const { value: simulatedTransactionResponse } =
    await connection.simulateTransaction(transaction, {
      replaceRecentBlockhash: true,
      commitment: "processed",
    });
  const { err, logs } = simulatedTransactionResponse;

  if (err) {
    // Simulation error, we can check the logs for more details
    // If you are getting an invalid account error, make sure that you have the input mint account to actually swap from.
    ctx.reply("Simulation Error:");
    console.error({ err, logs });
    return;
  }

  const serializedTransaction = Buffer.from(transaction.serialize());
  const blockhash = transaction.message.recentBlockhash;

  const transactionResponse = await transactionSenderAndConfirmationWaiter({
    connection,
    serializedTransaction,
    blockhashWithExpiryBlockHeight: {
      blockhash,
      lastValidBlockHeight: swapResult.lastValidBlockHeight,
    },
  });

  // If we are not getting a response back, the transaction has not confirmed.
  if (!transactionResponse) {
    ctx.reply("Transaction not confirmed");
    return;
  }

  if (transactionResponse.meta?.err) {
    console.error(transactionResponse.meta?.err);
  }

  ctx.reply(
    `Buy completed.\nYou can check here : https://solscan.io/tx/${signature}`
  );
  // appendToHistory(wallet.publicKey.toBase58(), signature);
}

export async function sell(ctx: any, tokenAddress: any, amount: any) {
  const jupiterQuoteApi = createJupiterApiClient();
  const wallet = new Wallet(adminWallet);
  // console.log("Wallet:", wallet.publicKey.toBase58());

  // Make sure that you are using your own RPC endpoint.
  const connection = new Connection("https://api.mainnet-beta.solana.com");
  const tokenMintAddress = new PublicKey(tokenAddress);
  const tokenAccountInfo =
  await connection.getParsedAccountInfo(tokenMintAddress);
  const tokenData = tokenAccountInfo.value?.data;
  console.log(tokenData);
  let decimal = 8;
  if (
    typeof tokenData === "object" &&
    tokenData !== null &&
    "parsed" in tokenData &&
    "info" in tokenData.parsed
  ) {
    const parsedData = tokenData.parsed.info;
    decimal = parsedData.decimals;
  } else {
    console.log("Token data is empty or not in the expected format.");
    return;
  }

  const amountBig = Math.floor(amount * Math.pow(10, decimal));
  const quote = await jupiterQuoteApi.quoteGet({
    inputMint: tokenAddress,
    outputMint: 'So11111111111111111111111111111111111111112',
    amount: amountBig,
    slippageBps: 50,
    onlyDirectRoutes: false,
    asLegacyTransaction: false,
  });

  if (!quote) {
    ctx.reply("Error occured: unable to quote");
    return;
  }

  // Get serialized transaction
  const swapResult = await jupiterQuoteApi.swapPost({
    swapRequest: {
      quoteResponse: quote,
      userPublicKey: wallet.publicKey.toBase58(),
      dynamicComputeUnitLimit: true,
      prioritizationFeeLamports: "auto",
      // prioritizationFeeLamports: {
      //   autoMultiplier: 2,
      // },
    },
  });

  console.dir(swapResult, { depth: null });

  // Serialize the transaction
  const swapTransactionBuf = Buffer.from(swapResult.swapTransaction, "base64");
  var transaction = VersionedTransaction.deserialize(swapTransactionBuf);

  // Sign the transaction
  transaction.sign([wallet.payer]);
  const signature = getSignature(transaction);

  // We first simulate whether the transaction would be successful
  const { value: simulatedTransactionResponse } =
    await connection.simulateTransaction(transaction, {
      replaceRecentBlockhash: true,
      commitment: "processed",
    });
  const { err, logs } = simulatedTransactionResponse;

  if (err) {
    // Simulation error, we can check the logs for more details
    // If you are getting an invalid account error, make sure that you have the input mint account to actually swap from.
    ctx.reply("Simulation Error:");
    console.error({ err, logs });
    return;

  }

  const serializedTransaction = Buffer.from(transaction.serialize());
  const blockhash = transaction.message.recentBlockhash;

  const transactionResponse = await transactionSenderAndConfirmationWaiter({
    connection,
    serializedTransaction,
    blockhashWithExpiryBlockHeight: {
      blockhash,
      lastValidBlockHeight: swapResult.lastValidBlockHeight,
    },
  });

  // If we are not getting a response back, the transaction has not confirmed.
  if (!transactionResponse) {
    ctx.reply("Transaction not confirmed");
    return;
  }

  if (transactionResponse.meta?.err) {
    console.error(transactionResponse.meta?.err);
  }

  ctx.reply(`Sell completed.\nYou can check here : https://solscan.io/tx/${signature}`);
  // appendToHistory(wallet.publicKey.toBase58(), signature);
}

function appendToHistory(walletAddress: any, txHash: any) {
  const historyPath = "history.json";
  let history = [];

  try {
    // Try to read the existing history file
    const historyRaw = fs.readFileSync(historyPath, { encoding: "utf8" });
    history = JSON.parse(historyRaw);
  } catch (error) {
    // If there's an error (e.g., file doesn't exist), start with an empty history array
    console.log(
      "No existing history found or error reading file. Starting fresh."
    );
  }

  // Append the new record
  history.push({ walletAddress, txHash });

  // Save the updated history back to the file
  fs.writeFileSync(historyPath, JSON.stringify(history, null, 2)); // Pretty print the JSON
}

bot.start((ctx) => {
  ctx.reply("Welcome to your Telegram bot!");
});

bot.help((ctx) => {
  let text = "\n◽️ Welcome to MySolanaJupiterBot. ◽️" + "\n\n";
  text +=
    "This is a list of all the things I'm capable of at the moment. " + "\n\n";
  text +=
    "Please add me to your group first before using any of my commands." +
    "\n\n";
  text +=
    "- Type /buy <Token Address> <Amount> | to buy given Token with SOL" +
    "\n\n";
  text +=
    "- Type /sell <Token Address> <Amount> | to sell given Token and earn SOL" +
    "\n\n";
  text += "- Type /help | to show all commands" + "\n\n";
  text += "Click here for a tutorial on how to set me up";

  ctx.reply(text);
});

bot.command("buy", async (ctx) => {
  let input = ctx.message.text.split(/\s+/);
  if (input.length != 3) {
    ctx.reply("Wrong Input");
    return;
  }
  let tokenAddress = input[1];
  let amount = input[2];
  await buy(ctx, tokenAddress, amount);
});

bot.command("sell", async (ctx) => {
  let input = ctx.message.text.split(/\s+/);
  if (input.length != 3) {
    ctx.reply("Wrong Input");
    return;
  }
  let tokenAddress = input[1];
  let amount = input[2];
  await sell(ctx, tokenAddress, amount);
});

bot.launch();
