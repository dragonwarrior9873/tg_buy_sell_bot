  import {
    Connection,
    Keypair,
  } from '@solana/web3.js';
  import bs58 from "bs58";
  export const devMode = false;
  export const adminPrivateKey = '';
  export const adminWallet =  Keypair.fromSecretKey(bs58.decode(adminPrivateKey));
  export const connection = new Connection(!devMode? 'https://hardworking-warmhearted-road.solana-mainnet.quiknode.pro/40b01d427606766d75d2031691b399ed523d3d4e/' : 'https://solana-devnet.g.alchemy.com/v2/6Y0EFRTX1kn0CH2cLDm-qsW5oGlQv5S7', 'confirmed');
  export const walletCount = 5; //new wallet count
  export const tokenAddress = devMode ? '6nNmjAAsR57NbRZeWnRaYhoKj2Uyn4yLQaKyyLTJGYrx' : 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
  export const tokenDecimal = devMode? 9 : 8;
  export const minAmount = 20.0;
  export const maxAmount = 100;
  export const minTime  = 6; //10min7/10
  export const maxTime  = 36  //1hr/100
  export const buyWeight  = 0.8
  export interface WalletType {
    publicKey: string;
    secretKey: string;
    amount: Number;
    usdebt: Number;
  }
  

  
