
import * as fs from 'fs';
import { TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID, getOrCreateAssociatedTokenAccount, transfer } from '@solana/spl-token';
import {
  Keypair,
  PublicKey,
  Transaction, SystemProgram
} from '@solana/web3.js';

import {
  connection,
  adminWallet,
  walletCount,
  WalletType,
  tokenAddress,
  minAmount,
  maxAmount,
  tokenDecimal
} from './config';

// async function getWalletBalance(adminPrivateKey: string, connection: Connection): Promise<number> {
//   const adminPublicKey = Keypair.fromSecretKey(Buffer.from(adminPrivateKey, 'base64')).publicKey;

//   const balance = await connection.getBalance(adminPublicKey);
//   return balance / Math.pow(10, 9); // Convert lamports to SOL
// }

async function generateSolanaWallets(walletCount: number): Promise<WalletType[]> {
  const wallets: WalletType[] = [];

  for (let i = 0; i < walletCount; i++) {
    const keypair = Keypair.generate();
    console.log(keypair.secretKey);
    wallets.push({
      publicKey: keypair.publicKey.toBase58(),
      secretKey: Buffer.from(keypair.secretKey).toString('base64'),
      amount: 0,
      usdebt: 0,
    });
  }

  return wallets;
}
async function saveWalletsToFile(wallets: WalletType[]) {
  const jsonData = JSON.stringify(wallets, null, 2);
  fs.writeFileSync('addresses.json', jsonData);
}

async function sendFundsToWallets(wallets: WalletType[]) {
  // const connection = new Connection(process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com');


  const adminPublicKey = adminWallet.publicKey;
  console.log("admin wallet ", adminPublicKey)

  // Get SOL price
  const solPrice = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd')
    .then(response => response.json())
    .then(data => data.solana.usd);

  // Calculate funds to send to each wallet
  // const minAmount = minAmount; // $10
  // const maxAmount = 100; // $100
  console.log("sol Price ", solPrice);
  // const usdebtMintAddress = new PublicKey(tokenAddress); // Ensure this is the correct USDEBT mint address
  // const usdebtAmountToSend = 0.0001; // USDEBT has 6 decimal places

  // const amountToSend = usdebtAmountToSend * Math.pow(10, tokenDecimal);

  for (const wallet of wallets) {
    const recipient = Keypair.fromSecretKey(Buffer.from(wallet.secretKey, 'base64'));

    try {
      const amount = (Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount);

      const lamports = Math.floor(amount / solPrice * 1e9); // Convert SOL to lamports
      wallet.amount = lamports * 1e-9;
      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: adminPublicKey,
          toPubkey: recipient.publicKey,
          lamports,
        })
      );

      while(true){
        try
        {
          await connection.sendTransaction(transaction, [adminWallet]);
          break;
        }catch(error){

          console.log("send fund error, retry until success");
          await new Promise(resolve => setTimeout(resolve, 3000));
        }
      }
      console.log(`Sent $${amount} = ${lamports * 1e-9}SOL to ${wallet.publicKey}`);

      // const destPublicKey = new PublicKey(wallet.publicKey);
      // // Ensure the admin's USDEBT token account and the recipient's token account exist
      // const fromTokenAccount = await getOrCreateAssociatedTokenAccount(connection, adminWallet, usdebtMintAddress, adminPublicKey);
      // console.log("fromTokenAccont ", fromTokenAccount.address)
      // const toTokenAccount = await getOrCreateAssociatedTokenAccount(connection, adminWallet, usdebtMintAddress, recipient.publicKey);
      // console.log("toTokenAccount ", toTokenAccount.address)

      // // Transfer USDEBT
      // await transfer(connection, adminWallet, fromTokenAccount.address, toTokenAccount.address, adminPublicKey, 500, [adminWallet, recipient]);
      // console.log(`Sent ${usdebtAmountToSend} USDEBT to ${wallet.publicKey}`);

      // Delay to avoid rate limits
      await new Promise(resolve => setTimeout(resolve, 5000));
    } catch (error) {
      console.error("Failed to send USDEBT:", error);
    }

    // await sleep(5000);
  }

}


async function main() {
  try {

    const wallets = await generateSolanaWallets(walletCount);
    await saveWalletsToFile(wallets);
    // const wallets: WalletType[] = JSON.parse(fs.readFileSync('addresses.json', 'utf-8'));
    console.log(`${walletCount} wallets generated and saved to addresses.json`);
    await sendFundsToWallets(wallets);
  } catch (error) {
    console.error('Error generating Solana wallets:', error);
  }
}

main().then(() => {
  console.log('Finished');
});
