
# Arb Jupiter Bot - JUPV4 

This bot is to allow you to buy and sell tokens on the Solana blockchain. The bot is currently written in nodejs and uses the Jupiter V6 SDK to execute trades.

## nav

 ⚡️[install](#install)

# install

> Please don't use `npm`, use `yarn` instead.(node version more than 18)

```bash
$ yarn
```

Set your wallet private key in the `./core/config.ts` file

```js
export const adminPrivateKey = '...'
```

# quickstart

1. Clone this repo
2. Install dependencies
3. Set your wallet private key in the `./core/config.ts` file
4. Run `yarn start` to start the Config Wizard

```
  Usage:
    $ yarn start
      This will open Config Wizard and start the bot

```

# Slippage management

Advanced slippage handling has been added to the code. 
	
## BPS slippage

Simple BPS slippage. The slippage is set in the Jupiter SDK. Make sure your percentage profit is a few points above the slippage. 

  const quote = await jupiterQuoteApi.quoteGet({
    inputMint: "So11111111111111111111111111111111111111112",
    outputMint: tokenAddress,
    amount: amountBig,
    slippageBps: 50, // set bps value you want
    onlyDirectRoutes: false,
    asLegacyTransaction: false,
  });